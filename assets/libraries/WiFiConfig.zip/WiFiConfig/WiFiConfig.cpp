#include "WiFiConfig.h"

WeatherReport *report_ptr = nullptr;
RemoteData *data_ptr = nullptr;

void OnReportRecv(const uint8_t * mac, const uint8_t *incomingData, int len) {

  Serial.println("Weather report received.");
  memcpy(report_ptr, incomingData, sizeof(WeatherReport));

}

void OnDataRecv(const uint8_t * mac, const uint8_t *incomingData, int len) {

  Serial.println("Remote data received.");
  memcpy(data_ptr, incomingData, sizeof(RemoteData));

}

void wifi_setup()
{
    // Set device as a Wi-Fi Station
    WiFi.mode(WIFI_STA);

    // Init ESP-NOW
    if (esp_now_init() != ESP_OK) {
        Serial.println("Error initializing wifi setup for ESP32");
        return;
    }
}

void peer_setup(uint8_t *broadcastAddress)
{
  esp_now_peer_info_t peerInfo;

  // Register peer
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }
}

void send_report(uint8_t *broadcastAddress, WeatherReport report)
{
  esp_now_send(broadcastAddress, (uint8_t *) &report, sizeof(report));
}

void set_report_receiver(WeatherReport *report)
{
  report_ptr = report;
  esp_now_register_recv_cb(esp_now_recv_cb_t(OnReportRecv));
}

void send_data(uint8_t *broadcastAddress, RemoteData data)
{
  esp_now_send(broadcastAddress, (uint8_t *) &data, sizeof(data));
}

void set_data_receiver(RemoteData *data)
{
  data_ptr = data;
  esp_now_register_recv_cb(esp_now_recv_cb_t(OnDataRecv));
}