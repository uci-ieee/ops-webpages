#ifndef WIFICONFIG_H
#define WIFICONFIG_H

#include <WiFi.h>
#include <esp_now.h>
#include <string.h>
#include <cstdint>

struct WeatherReport {
  uint8_t temperature;
  uint8_t humidity;
  uint8_t light;
};

struct RemoteData {
  uint8_t vx;
  uint8_t vy;
  uint8_t sw;
};

void wifi_setup();

void peer_setup(uint8_t *broadcastAddress);

void send_report(uint8_t *broadcastAddress, WeatherReport report);

void set_report_receiver(WeatherReport *report);

void send_data(uint8_t *broadcastAddress, RemoteData data);

void set_data_receiver(RemoteData *data);

#endif